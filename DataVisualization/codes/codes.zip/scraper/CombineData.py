import json
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import math
import langdetect
from langdetect import detect
import nltk
from nltk.corpus import stopwords
from nltk import word_tokenize, pos_tag
import string
from zhon.hanzi import punctuation
import os
KEYS = ['id', 'date', 'time', 'user_id', 'username', 'likes_count', 'replies_count', 'retweets_count', 'tweet', 'urls', 'language', 'mentions', 'hashtags', 'link', 'retweet', 'reply_to']
VERIFIED = True
matplotlib.use('Qt5Agg')


def combineTweets():
    InfoDB = []
    IDSet = set()
    if not VERIFIED:
        f1 = open(r'downloads/GPT-non-verified.json', 'r', encoding='utf-8', errors='ignore').readlines()
        f2 = open(r'downloads/GPT-non-verified-1.json', 'r', encoding='utf-8', errors='ignore').readlines()
        f3 = open(r'downloads/GPT-non-verified-2.json', 'r', encoding='utf-8', errors='ignore').readlines()
        f1.extend(f2)
        f1.extend(f3)
    else:
        f1 = open(r'downloads/GPT.json', 'r', encoding='utf-8', errors='ignore').readlines()
        f2 = open(r'downloads/GPT-1.json', 'r', encoding='utf-8', errors='ignore').readlines()
        f1.extend(f2)

    for indices, line in enumerate(f1):
        ll = json.loads(line)
        if ll['id'] not in IDSet:
            InfoDB.append({key: ll[key] for key in KEYS})
            IDSet.add(ll['id'])
    InfoDB = pd.DataFrame(InfoDB)
    print(InfoDB)
    InfoDB.to_csv(r'./outputs/Tweets.csv', encoding='utf-8', index=False)


def CombineCSV():
    fromBase = r'./outputs/Crawl'
    df = None
    for file in os.listdir(fromBase):
        if not file.startswith('ChatGPT') or not file.endswith('.csv'):
            continue
        if df is None:
            df = pd.read_csv(os.path.join(fromBase, file))
        else:
            df0 = pd.read_csv(os.path.join(fromBase, file))
            df = pd.concat((df, df0), axis=0, join='inner')
    df = df.drop_duplicates(subset=['Tweet URL'])
    df = df.sort_values(by='Timestamp', ascending=True)
    df.to_csv(r'./outputs/ChatGPTScrawl.csv', index=False)
    print(df)


def CombineFollowers():
    f = json.load(open(r'./outputs/data/followerInfo_FULL.json', 'r', encoding='utf-8', errors='ignore'))
    for user in f:
        if isinstance(user['following'], int):
            user['following'] = '0'
        elif user['following'].endswith('万'):
            user['following'] = str(float(user['following'].replace(',', '').split('万')[0]) * 10) + 'k'
        if isinstance(user['follower'], int):
            user['follower'] = '0'
        elif user['follower'].endswith('万'):
            user['follower'] = str(float(user['follower'].replace(',', '').split('万')[0]) * 10) + 'k'
    f = pd.DataFrame(f)
    f.to_csv(r'./data/Followers_new.csv', encoding='utf-8', index=False)


def tokenize(w):
    STOP = stopwords.words('english')
    # Section: remove punctuation
    DOTS = string.punctuation+punctuation
    w = w.lower() if isinstance(w, str) else str(w).lower()
    for i in DOTS:
        w = w.replace(i, '')
    # Section: tokenize
    tokens = word_tokenize(w)
    # Section: remove stopWords
    tokens = [i for i in tokens if i not in STOP]
    # TODO: tags
    # tags = pos_tag(tokens)
    return tokens


def CombineKeywords():
    retainKEYS = ['id', 'date', 'time', 'username', 'likes_count', 'replies_count', 'retweets_count']
    emoTweets = pd.read_csv('./outputs/emoTweets_vec.csv').drop_duplicates(['id'])
    emoIndices = emoTweets['id'].tolist()
    allTweets = pd.read_csv('./outputs/Tweets.csv')[retainKEYS]
    allTweets = allTweets.loc[allTweets['id'].isin(emoIndices)].sort_values(by='likes_count', ascending=False).drop_duplicates(['id'], keep='first')
    # print(allTweets, '\n\n', emoTweets)
    result = pd.merge(emoTweets, allTweets, how='left', on='id')
    keyWords = []
    # Section: extract keywords from each tweet
    for rowIndices, row in result.iterrows():
        Keys = tokenize(row['tweet'])
        keyWords.append(Keys)
    result['keyWords'] = keyWords
    result.to_csv(r'./outputs/FinalEmoDataVec.csv', index=False)


def detectLan(savePath=r'./outputs/ChatGPTtweets.csv', fromPath=r'./outputs/ChatGPTScrawl.csv'):
    remainKeys = ['UserName', 'Timestamp', 'Text', 'Embedded_text', 'Comments', 'Likes', 'Retweets', 'Tweet URL']
    df = pd.read_csv(fromPath)[remainKeys]
    tweets = df['Embedded_text'].tolist()
    languages = []
    KeyWords = []
    for tweet in tweets:
        print(tweet)
        try:
            languages.append(detect(tweet))
        except:
            languages.append('error')
        KeyWords.append(tokenize(tweet))
    df['language'] = languages
    df['keyWords'] = KeyWords
    df.to_csv(savePath, index=False, encoding='utf-8')


def netWorkInfo():
    net = pd.read_csv('./outputs/Crawl/FollowingNet.csv')
    concerns = net['user'].tolist()
    concise = dict()
    for indices, row in net.iterrows():
        followers = json.loads(row['list'].replace('\'', '\"'))
        print(row['user'], len(followers))
        att_following = [f for f in followers if f in concerns]
        print(len(att_following), att_following)
        print('-' * 20)
        concise[row['user']] = att_following
    json.dump(concise, open(r'./data/FollowingNet.json', 'w'), indent=4)


def NetJson2CSV():
    followers_df = pd.read_excel(r'./data/Followers_new.xlsx', sheet_name="Followers")
    followers_df.drop_duplicates(subset=['user'], keep='first')
    keys = list(followers_df.columns)
    keys.remove('Unnamed: 0')
    followers_df = followers_df[keys]
    keys.remove('user')
    print(keys)

    selected = dict(json.load(open(r'./data/FollowingNet.json', 'r')))
    followerTMP = {key: 0 for key in selected.keys()}
    for _, ll in selected.items():
        for name in ll:
            followerTMP[name] += 1

    csvItems = []
    for name, ll in selected.items():
        csvItems.append({'name': name, 'list': ll, 'followerLocal': followerTMP[name]})
        item = followers_df[followers_df['user'] == name].iloc[0]
        for key in keys:
            csvItems[-1][key] = item[key]
    csvItems = pd.DataFrame(csvItems)
    # xx, yy = randomPoints(len(csvItems))

    radius = 2 * math.pi / len(csvItems)
    R = 250
    xx, yy = [], []
    for i in range(len(csvItems)):
        xx.append(int(R * math.cos(i * radius) + R))
        yy.append(int(R * math.sin(i * radius) + R))

    csvItems['X'] = xx
    csvItems['Y'] = yy
    csvItems.to_csv(r'./codes/data/FollowingNet.csv', index=False)


# 传入顶点的x坐标，y坐标，生成的点个数num
def pltShow(xx, yy, num):
    z = np.random.random(size=[xx.size, num])

    x = (z / sum(z)).T.dot(xx)
    y = (z / sum(z)).T.dot(yy)

    # 绘制点：黄色
    plt.plot(x, y, 'yo')
    plt.grid(True)

    # 绘制顶点：绿色
    for i in range(xx.size):
        plt.plot(xx[i], yy[i], 'go')

    plt.show()


# 随机生成N边形的N个顶点
def createPolygon(n):
    xxx = np.random.randint(1, 500, n)
    yyy = np.random.randint(1, 500, n)
    return xxx, yyy


def randomPoints(n=21):
    # xx, yy = createPolygon(4)
    # 多边形内随机生成点
    # pltShow(xx, yy, 30)
    xlist, ylist = list(range(500)), list(range(500))
    xx, yy = [], []
    for _ in range(n):
        xind = np.random.randint(0, len(xlist))
        yind = np.random.randint(0, len(ylist))

        xv, yv = xlist[xind], ylist[yind]
        xx.append(xv)
        yy.append(yv)
        xlist.remove(xv)
        ylist.remove(yv)

    plt.plot(xx, yy, 'yo')
    plt.grid(True)

    plt.show()
    return xx, yy


if __name__ == '__main__':
    # CombineKeywords()
    # CombineCSV()
    # detectLan()
    # CombineFollowers()
    # netWorkInfo()
    NetJson2CSV()
    # randomPoints()
