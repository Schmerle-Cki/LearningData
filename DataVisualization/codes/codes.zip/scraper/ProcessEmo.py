import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
import json
import matplotlib
import matplotlib.pyplot as plt

# matplotlib.use('Qt5Agg')
eps = 1e-20
emoColor = {'Anger': 'r', 'Disgust': 'b', 'Fear': 'c', 'Joy': 'y', 'Sadness': 'm', 'Surprise': 'k'}
useful = True
Postfix = 'Useful' if useful else ''


def clamp(v):
    if abs(v) > eps:
        return v
    return eps


def clampArray(a):
    assert len(a.shape) == 2
    for i in range(a.shape[0]):
        for j in range(a.shape[1]):
            a[i][j] = clamp(a[i][j])
    return a


emotions = pd.read_csv(r'./data/Emo/EmoTweets.csv')
if useful:
    emotions = emotions.dropna(axis=0, how='any')

emoVec = emotions['emoVec'].tolist()
for indices, emo in enumerate(emoVec):
    emoVec[indices] = json.loads(emo.replace('\'', '\"'))

emoVec = np.array(emoVec)
pca = PCA(n_components=2)
pca.fit(emoVec)
emoVec = pca.transform(emoVec)
# emoVec = np.sqrt(clampArray(emoVec))
# TODO: >=0
emoVec[:, 0] -= min(emoVec[:, 0])
emoVec[:, 1] -= min(emoVec[:, 1])
emoVec += eps
emotions['X'] = emoVec[:, 0].tolist()
emotions['Y'] = emoVec[:, 1].tolist()
emotions.to_csv(f'./data/Emo/PCAEmo{Postfix}.csv', index=False)

# TODO: transform
'''
X_mean = np.mean(emoVec[:, 0])
Y_mean = np.mean(emoVec[:, 1])
print(f'> Median: ({X_mean}, {Y_mean})')
Xs, Ys = [], []
for indices, row in emotions.iterrows():
    try:
        Xs.append(np.square(row['X'] * 1) ** 2 * 1)   # 立方根： np.cbrt
        Ys.append(np.square(row['Y'] * 1) ** 2 * 1)
        # Xs.append((2*int(row['X'] > X_mean)-1) * (row['X'] - X_mean) ** 2 + X_mean)
        # Ys.append((2*int(row['Y'] > Y_mean)-1) * (row['Y'] - Y_mean) ** 2 + Y_mean)
    except RuntimeWarning:
        print(row['X'], row['Y'])
emotions['X'] = Xs
emotions['Y'] = Ys
'''

# TODO: centers
centroids = {key: [0, 0] for key in emoColor.keys()}
groups = emotions.groupby(by='emotion')[['X', 'Y']].mean().reset_index()
for indices, row in groups.iterrows():
    centroids[row['emotion']] = [row['X'], row['Y']]
print(centroids)

# TODO: aviation points for each class
aviationCenter = {key: [0, 0] for key in emoColor.keys()}
for key in emoColor.keys():
    subDF = emotions[emotions['emotion'] == key]
    x, y, max_distance = 0, 0, -1.0
    for pointID, point in subDF.iterrows():
        dist = (point['X']-centroids[key][0]) ** 2 + (point['Y']-centroids[key][1]) ** 2
        if dist > max_distance:
            max_distance = dist
            x, y = point['X'], point['Y']
    aviationCenter[key] = [x, y]


categories = emotions['emotion'].tolist()
fig, ax = plt.subplots()
# circle = plt.Circle((X_mean, Y_mean), 0.2, color='r', fill=True)
textPoints = []
textMAXpoints = []
# ax.add_artist(circle)
ax.add_artist(plt.scatter(emotions['X'].tolist(), emotions['Y'].tolist(), c=[emoColor[category] for category in categories]))
for key, value in aviationCenter.items():
    ax.add_artist(plt.text(value[0],
                           value[1],
                           key,
                           fontsize=15,
                           color=emoColor[key],
                           verticalalignment="top",
                           horizontalalignment="left"
                           ))
    textPoints.append({'emo': key, 'X': centroids[key][0], 'Y': centroids[key][0]})
    textMAXpoints.append({'emo': key, 'X': value[0], 'Y': value[1]})
plt.axis("equal")
plt.show()

df = pd.DataFrame(textPoints)
df.to_csv(f'./codes/data/emoPoints{Postfix}.csv', index=False)
df = pd.DataFrame(textMAXpoints)
df.to_csv(f'./codes/data/emoMAXpoints{Postfix}.csv', index=False)