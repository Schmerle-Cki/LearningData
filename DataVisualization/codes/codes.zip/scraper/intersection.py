import pandas as pd
import os


def intersect():
    Base = r'./data'
    tweets_path = r'./data/tweets_new.xlsx'
    followers_path = r'./data/Followers_new.xlsx'
    emoTweets_path = r'./data/EmoTweets_new.xlsx'
    tweets_df = pd.read_excel(tweets_path, sheet_name="Tweets")
    followers_df = pd.read_excel(followers_path, sheet_name="Followers")
    emoTweets_df = pd.read_excel(emoTweets_path, sheet_name="emoVec")

    # 打印表数据，如果数据太多，会略去中间部分
    FollowerUser = followers_df['user']
    # FollowerUser = pd.read_csv(r'./outputs/Crawl/followers.csv')['0']
    TweetsUser = tweets_df['UserName'].tolist()
    TweetsUser = [str(name).split('@')[-1] for name in TweetsUser]
    EmoUser = emoTweets_df['UserName']
    EmoUser = [str(name).split('@')[-1] for name in EmoUser]

    # 打印头部数据，仅查看数据示例时常用
    # print(tweets_df.head())
    # 打印列标题
    # print(tweets_df.columns)
    # 打印行
    # print(tweets_df.index)
    # 描述数据
    # print(tweets_df.describe())
    Intersect = set(TweetsUser).intersection(set(FollowerUser.tolist()))
    print('\n\n\n')
    print(len(Intersect), Intersect)
    IntersectMore = set(EmoUser).intersection(Intersect)
    print(len(IntersectMore), IntersectMore)

    # Section: WRITE intersects into other sheets
    writer = pd.ExcelWriter(tweets_path)
    LargeIndices, SmallIndices = [], []
    for rowID, oneTweet in tweets_df.iterrows():
        userName = str(oneTweet['UserName']).split('@')[-1]
        if userName in Intersect:
            LargeIndices.append(rowID)
            if userName in IntersectMore:
                SmallIndices.append(rowID)
    tweets_df.to_excel(writer, sheet_name="Tweets")
    tweets_df.iloc[LargeIndices, :].to_excel(writer, sheet_name='intersect_user')
    tweets_df.iloc[SmallIndices, :].to_excel(writer, sheet_name='intersect_emo')
    writer.close()

    writer = pd.ExcelWriter(followers_path)
    LargeIndices, SmallIndices = [], []
    for rowID, oneTweet in followers_df.iterrows():
        userName = oneTweet['user']
        if userName in Intersect:
            LargeIndices.append(rowID)
            if userName in IntersectMore:
                SmallIndices.append(rowID)
    followers_df.to_excel(writer, sheet_name="Followers")
    followers_df.iloc[LargeIndices, :].to_excel(writer, sheet_name='intersect_user')
    followers_df.iloc[SmallIndices, :].to_excel(writer, sheet_name='intersect_emo')
    writer.close()

    writer = pd.ExcelWriter(emoTweets_path)
    LargeIndices, SmallIndices = [], []
    for rowID, oneTweet in emoTweets_df.iterrows():
        userName = str(oneTweet['UserName']).split('@')[-1]
        if userName in Intersect:
            LargeIndices.append(rowID)
            if userName in IntersectMore:
                SmallIndices.append(rowID)
    emoTweets_df.to_excel(writer, sheet_name="emoVec")
    emoTweets_df.iloc[LargeIndices, :].to_excel(writer, sheet_name='intersect_user')
    emoTweets_df.iloc[SmallIndices, :].to_excel(writer, sheet_name='intersect_emo')
    writer.close()


intersect()


