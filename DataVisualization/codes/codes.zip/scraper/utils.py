import os
import re
from time import sleep, time
import random
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import datetime
import pandas as pd
import platform
from selenium.webdriver.common.keys import Keys
# import pathlib
import csv
import json
import gc

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import urllib

SCROLL_LIMIT = 1


def get_data(card, save_images=False, save_dir=None):
    """Extract data from tweet card"""
    image_links = []

    try:
        username = card.find_element(By.XPATH, './/span').text
    except:
        return

    try:
        handle = card.find_element(By.XPATH, './/span[contains(text(), "@")]').text
    except:
        return

    try:
        postdate = card.find_element(By.XPATH, './/time').get_attribute('datetime')
    except:
        return

    try:
        text = card.find_element(By.XPATH, './/div[2]/div[2]/div[1]').text
    except:
        text = ""

    try:
        embedded = card.find_element(By.XPATH, './/div[2]/div[2]/div[2]').text
    except:
        embedded = ""

    # text = comment + embedded

    try:
        reply_cnt = card.find_element(By.XPATH, './/div[@data-testid="reply"]').text
    except:
        reply_cnt = 0

    try:
        retweet_cnt = card.find_element(By.XPATH, './/div[@data-testid="retweet"]').text
    except:
        retweet_cnt = 0

    try:
        like_cnt = card.find_element(By.XPATH, './/div[@data-testid="like"]').text
    except:
        like_cnt = 0

    '''
    try:
        elements = card.find_elements(By.XPATH, './/div[2]/div[2]//img[contains(@src, "https://pbs.twimg.com/")]')
        for element in elements:
            image_links.append(element.get_attribute('src'))
    except:
        image_links = []
    '''
    # if save_images == True:
    #	for image_url in image_links:
    #		save_image(image_url, image_url, save_dir)
    # handle promoted tweets

    '''
    try:
        promoted = card.find_element(By.XPATH, './/div[2]/div[2]/[last()]//span').text == "Promoted"
    except:
        promoted = False
    if promoted:
        return

    # get a string of all emojis contained in the tweet
    try:
        emoji_tags = card.find_elements_by_xpath('.//img[contains(@src, "emoji")]')
    except:
        return
    emoji_list = []
    for tag in emoji_tags:
        try:
            filename = tag.get_attribute('src')
            emoji = chr(int(re.search(r'svg\/([a-z0-9]+)\.svg', filename).group(1), base=16))
        except AttributeError:
            continue
        if emoji:
            emoji_list.append(emoji)
    emojis = ' '.join(emoji_list)
    '''

    # tweet url
    try:
        element = card.find_element(By.XPATH, './/a[contains(@href, "/status/")]')
        tweet_url = element.get_attribute('href')
    except:
        return
    tweet = (
        username, handle, postdate, text, embedded, '[]', reply_cnt, retweet_cnt, like_cnt, image_links, tweet_url)
    # print('****************\n', tweet)
    return tweet


# 配置driver
def init_driver(headless=True, proxy=None, show_images=False):
    """ initiate a chromedriver instance """
    # create instance of web driver
    '''
    chromedriver_path = chromedriver_autoinstaller.install()
    options = Options()
    if headless is True:

        print("Scraping on headless mode.")
        options.add_argument('--disable-gpu')
        options.headless = True
    else:
        options.headless = False
    options.add_argument('log-level=3')
    if proxy is not None:
        options.add_argument('--proxy-server=%s' % proxy)
    if show_images == False:
        prefs = {"profile.managed_default_content_settings.images": 2}
        options.add_experimental_option("prefs", prefs)
    '''
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-automation'])
    driver = webdriver.Chrome(options=options)
    # driver = webdriver.Chrome(options=options, executable_path=chromedriver_path)
    driver.set_page_load_timeout(100)
    return driver


# 关键字 翻页等
def log_search_page(driver, start_date, end_date, lang, display_type, words, to_account, from_account, hashtag,
                    filter_replies, proximity):
    """ Search for this query between start_date and end_date"""

    # format the <from_account>, <to_account> and <hash_tags>
    from_account = "%20(from%3A" + from_account + ")" if from_account is not None else ""
    to_account = "(to%3A" + to_account + ")%20" if to_account is not None else ""
    hash_tags = "(%23" + hashtag + ")%20" if hashtag is not None else ""
    end_date = "until%3A" + end_date + "%20" if end_date is not None else ""
    start_date = "%20since%3A" + start_date if start_date is not None else "" # + "%20"

    if display_type == "Latest" or display_type == "latest":
        display_type = "&f=live"
    elif display_type == "Image" or display_type == "image":
        display_type = "&f=image"
    else:
        display_type = ""

    # filter replies
    if filter_replies == True:
        filter_replies = "%20-filter%3Areplies"
    else:
        filter_replies = ""
    # proximity
    if proximity == True:
        proximity = "&lf=on"  # at the end
    else:
        proximity = ""

    print(words, from_account, to_account, hash_tags, end_date, start_date, lang, filter_replies, display_type,
          proximity)
    'https://twitter.com/search?f=live&q=ChatGPT%20(from%3ADataChaz)%20min_faves%3A8%20since%3A2022-11-01&src=typed_query'
    path = 'https://twitter.com/search?f=live&q=' + words[0] + from_account + '%20min_faves%3A0' + end_date + start_date + '&src=typed_query'  # + from_account + to_account + hash_tags + end_date + start_date + lang + filter_replies + display_type + proximity
    # path = 'https://twitter.com/search?q=' + words[0] + '%20min_faves%3A10' + from_account + end_date + start_date + '&src=typed_query&f=live'# + from_account + to_account + hash_tags + end_date + start_date + lang + filter_replies + display_type + proximity
    print(path)
    driver.get(path)
    sleep(random.randint(5, 10))
    return path


def get_last_date_from_csv(path):
    df = pd.read_csv(path)
    return datetime.datetime.strftime(max(pd.to_datetime(df["Timestamp"])), '%Y-%m-%dT%H:%M:%S.000Z')


# 模拟登录[........................
def log_in(driver, timeout=10):
    username = 'userName'
    password = 'Code'

    driver.get('https://www.twitter.com/login')
    sleep(5)
    username_el = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.NAME, 'text')))
    username_el.send_keys(username)
    sleep(timeout // 4)
    username_el.send_keys(Keys.RETURN)

    # username_xpath = '//input[@name="session[username_or_email]"]'
    # password_xpath = '//input[@name="session[password]"]' #

    # username_el = WebDriverWait(driver, timeout).until(EC.presence_of_element_located((By.XPATH, username_xpath)))
    # password_el = WebDriverWait(driver, timeout).until(EC.presence_of_element_located((By.XPATH, password_xpath)))
    password_el = WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.NAME, 'password')))

    # username_el.send_keys(username)
    password_el.send_keys(password)
    password_el.send_keys(Keys.RETURN)
    sleep(timeout // 4)


def keep_scroling(driver, data, writer, tweet_ids, scrolling, tweet_parsed, limit, scroll, last_position,
                  save_images=False):
    """ scrolling function for tweets crawling"""

    save_images_dir = "/images"

    if save_images == True:
        if not os.path.exists(save_images_dir):
            os.mkdir(save_images_dir)

    while scrolling and tweet_parsed < limit:
        sleep(random.uniform(1.5, 3.5))
        # get the card of tweets
        page_cards = driver.find_elements(By.XPATH, '//div[@data-testid="cellInnerDiv"]')
        for card in page_cards:
            tweet = get_data(card, save_images, save_images_dir)
            if tweet:
                # check if the tweet is unique
                tweet_id = ''.join(tweet[:-2])
                if tweet_id not in tweet_ids:
                    tweet_ids.add(tweet_id)
                    data.append(tweet)
                    last_date = str(tweet[2])
                    print("Tweet made at: " + str(last_date) + " is found.")
                    writer.writerow(tweet)
                    tweet_parsed += 1
                    if tweet_parsed >= limit:
                        break
                    # FIXME: save and clear memory
                    if tweet_parsed % 5000 == 4:
                        sleep(20)
                        del data
                        gc.collect()
                        data = []
        scroll_attempt = 0
        while tweet_parsed < limit:
            # check scroll position
            scroll += 1
            print("scroll ", scroll, '| limit ', limit, )
            sleep(random.uniform(0.5, 1.5))
            driver.execute_script('window.scrollTo(0, document.body.scrollHeight);')
            curr_position = driver.execute_script("return window.pageYOffset;")
            if last_position == curr_position:
                scroll_attempt += 1
                # end of scroll region
                if scroll_attempt >= SCROLL_LIMIT:
                    scrolling = False
                    break
                else:
                    sleep(random.uniform(5.5, 15.5))  # attempt another scroll
            else:
                last_position = curr_position
                break
    return driver, data, writer, tweet_ids, scrolling, tweet_parsed, scroll, last_position


def get_users_follow(users, headless, follow=None, verbose=1, wait=2):
    """ get the following or followers of a list of users """
    # initiate the driver
    driver = init_driver(headless=headless)
    sleep(wait)
    # log in (the .env file should contain the username and password)
    log_in(driver)
    sleep(wait)
    # followers and following dict of each user
    follows_users = {}

    for user in users:
        # log user page
        # print("Crawling @" + user + " " + follow)
        driver.get('https://twitter.com/' + user)
        sleep(random.uniform(wait - 0.5, wait + 0.5))
        # find the following or followers button
        driver.find_element(By.XPATH,
                            '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div/div/div/div[5]/div[2]/a/span[2]/span').click()
        # driver.find_element(By.XPATH, '//a[contains(@href,"/' + follow + '")]/span[1]/span[1]').click()
        sleep(random.uniform(wait - 0.5, wait + 0.5))
        # if the log in fails, find the new log in button and log in again.
        scrolling = True
        last_position = driver.execute_script("return window.pageYOffset;")
        follows_elem = []
        follow_ids = set()

        while scrolling:
            # get the card of following or followers
            page_cards = driver.find_elements(By.XPATH, '//div[contains(@data-testid,"UserCell")]')
            for card in page_cards:
                # get the following or followers element
                element = card.find_element(By.XPATH, './/div[1]/div[1]/div[1]//a[1]')
                follow_elem = element.get_attribute('href')
                # append to the list
                follow_id = str(follow_elem)
                follow_elem = '@' + str(follow_elem).split('/')[-1]
                # TODO: 爬取首页链接
                if follow_id not in follow_ids:
                    follow_ids.add(follow_id)
                    follows_elem.append(follow_elem)
                if verbose:
                    print(follow_elem)
            print("Found " + str(len(follows_elem)) + 'followers:', follows_elem)
            scroll_attempt = 0
            while True:
                sleep(random.uniform(wait - 0.5, wait + 0.5))
                driver.execute_script('window.scrollTo(0, document.body.scrollHeight);')
                sleep(random.uniform(wait - 0.5, wait + 0.5))
                curr_position = driver.execute_script("return window.pageYOffset;")
                if last_position == curr_position:
                    scroll_attempt += 1
                    print('> Loading Attempted: ', scroll_attempt)

                    # end of scroll region
                    if scroll_attempt == 10:
                        res = pd.DataFrame(follows_elem)
                        res.to_csv(f'./outputs/Crawl/followers_{time()}.csv', encoding='gbk')
                        sleep(300)
                    elif scroll_attempt >= 20:
                        scrolling = False
                        break
                    else:
                        sleep(random.uniform(wait * 2 - 2, wait * 2 + 2))  # attempt another scroll
                else:
                    last_position = curr_position
                    break
            sleep(random.uniform(wait - 2, wait + 2))  # attempt another scroll
            if (len(follows_elem) // 100) % 3 == 0:
                sleep(random.uniform(wait * 2 - 5, wait * 2 + 1))  # attempt another scroll
            if (len(follows_elem) // 100) % 9 == 5:
                sleep(random.uniform(wait * 6 - 5, wait * 6 + 5))  # attempt another scroll

        follows_users[user] = follows_elem
        res = pd.DataFrame(follows_elem)
        res.to_csv('./outputs/Crawl/followers.csv', encoding='gbk')
    return follows_users


def get_following(users, headless, wait=3):
    driver = init_driver(headless=headless)
    sleep(wait)

    log_in(driver)
    sleep(wait)
    follows_users = {}

    for user in users:
        driver.get(f'https://twitter.com/{user}/following')
        sleep(random.uniform(wait * 3 - 0.5, wait * 3 + 0.5))
        # if the log in fails, find the new log in button and log in again.
        scrolling = True
        last_position = driver.execute_script("return window.pageYOffset;")
        following_elem = []

        while scrolling:
            # get the card of following or followers
            page_cards = driver.find_elements(By.XPATH, '//div[contains(@data-testid,"cellInnerDiv")]')
            for card in page_cards:
                follower = card.text.split('Follow')[0].split('@')[-1].strip()
                print(follower)
                if follower not in following_elem and len(follower) > 1:
                    following_elem.append(follower)

            scroll_attempt = 0
            while True:
                sleep(random.uniform(wait - 0.5, wait + 0.5))
                driver.execute_script('window.scrollTo(0, document.body.scrollHeight);')
                sleep(random.uniform(wait * 2 - 0.5, wait * 2 + 0.5))
                curr_position = driver.execute_script("return window.pageYOffset;")
                if last_position == curr_position:
                    scroll_attempt += 1
                    print('> Loading Attempted: ', scroll_attempt)

                    # end of scroll region
                    if scroll_attempt == 12:
                        scrolling = False
                        break
                    else:
                        sleep(random.uniform(wait * 10 - 2, wait * 10 + 2))  # attempt another scroll
                else:
                    last_position = curr_position
                    break
            sleep(random.uniform(wait - 2, wait + 2))  # attempt another scroll
            if (len(following_elem) // 10) % 3 == 0:
                sleep(random.uniform(wait * 3 - 5, wait * 3 + 1))  # attempt another scroll
            if (len(following_elem) // 10) % 9 == 5:
                sleep(random.uniform(wait * 6 - 5, wait * 6 + 5))  # attempt another scroll

        print(f'> User {user} with {len(following_elem)} followings')
        follows_users[user] = following_elem

    res = pd.DataFrame([{'user': key, 'list': value} for key, value in follows_users.items()])
    res.to_csv('./outputs/Crawl/FollowingNet_2.csv', encoding='gbk', index=False)
    return follows_users


# link文件

def check_exists_by_link_text(text, driver):
    try:
        driver.find_element(By.LINK_TEXT, text)
    except NoSuchElementException:
        return False
    return True


def scrap(start_date=None, max_date=None, words=None, to_account=None, from_accounts=None, interval=1, lang=None,
          headless=True, limit=float("inf"), display_type="Top", resume=False, proxy=None, hashtag=None,
          show_images=False, save_images=False, save_dir="outputs", filter_replies=False, proximity=False):
    """
    scrap data from twitter using requests, starting from start_date until max_date. The bot make a search between each start_date and end_date
    (days_between) until it reaches the max_date.

    return:
    data : df containing all tweets scraped with the associated features.
    save a csv file containing all tweets scraped with the associated features.
    """

    # ------------------------- Variables :
    # header of csv
    header = ['UserScreenName', 'UserName', 'Timestamp', 'Text', 'Embedded_text', 'Emojis', 'Comments', 'Likes',
              'Retweets',
              'Image link', 'Tweet URL']
    # list that contains all data
    data = []
    # unique tweet ids
    tweet_ids = set()
    # write mode
    write_mode = 'w'
    # start scraping from start_date until <max_date>
    init_date = start_date  # used for saving file
    # add the <interval> to <start_dateW to get <end_date> for the first refresh
    # FIXME: <end_date> set to None
    end_date = None
    # end_date = datetime.datetime.strptime(start_date, '%Y-%m-%d') + datetime.timedelta(days=interval)
    # set refresh at 0. we refresh the page for each <interval> of time.
    refresh = 0

    # ------------------------- settings :
    # file path
    if words:
        if type(words) == str:
            words = words.split("//")
            path = save_dir + "/" + words[0] + '_' + str(init_date).split(' ')[0] + '_' + \
                   str(max_date).split(' ')[0] + '.csv'
        else:
            path = save_dir + "/" + words[0] + '_' + str(init_date).split(' ')[0] + '_' + \
                   str(max_date).split(' ')[0] + '.csv'
    # elif from_account:
    #    path = save_dir + "/" + from_account + '_' + str(init_date).split(' ')[0] + '_' + str(max_date).split(' ')[
    #        0] + '.csv'
    # elif to_account:
    #    path = save_dir + "/" + to_account + '_' + str(init_date).split(' ')[0] + '_' + str(max_date).split(' ')[
    #        0] + '.csv'
    elif hashtag:
        path = save_dir + "/" + hashtag + '_' + str(init_date).split(' ')[0] + '_' + str(max_date).split(' ')[
            0] + '.csv'
    # create the <save_dir>
    os.makedirs(save_dir, exist_ok=True)
    # show images during scraping (for saving purpose)
    show_images = save_images
    # initiate the driver
    driver = init_driver(headless, proxy, show_images)
    sleep(2)
    log_in(driver)
    sleep(2)
    # resume scraping from previous work
    if resume:
        start_date = str(get_last_date_from_csv(path))[:10]
        write_mode = 'a'

    # ------------------------- start scraping : keep searching until max_date
    # open the file
    with open(path, write_mode, newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if write_mode == 'w':
            # write the csv header
            writer.writerow(header)
        # Section: <Search By Date> log search page for a specific <interval> of time and keep scrolling until scrolling stops or reach the <max_date>
        '''
        while end_date <= datetime.datetime.strptime(max_date, '%Y-%m-%d'):
            # number of scrolls
            scroll = 0
            # convert <start_date> and <end_date> to str
            if type(start_date) != str:
                start_date = datetime.datetime.strftime(start_date, '%Y-%m-%d')
            if type(end_date) != str:
                end_date = datetime.datetime.strftime(end_date, '%Y-%m-%d')
            # log search page between <start_date> and <end_date>
            path = log_search_page(driver=driver, words=words, start_date=start_date,
                                   end_date=end_date, to_account=to_account,
                                   from_account=from_account, hashtag=hashtag, lang=lang,
                                   display_type=display_type, filter_replies=filter_replies, proximity=proximity)
            # number of logged pages (refresh each <interval>)
            refresh += 1
            # number of days crossed
            # days_passed = refresh * interval
            # last position of the page : the purpose for this is to know if we reached the end of the page or not so
            # that we refresh for another <start_date> and <end_date>
            last_position = driver.execute_script("return window.pageYOffset;")
            # should we keep scrolling ?
            scrolling = True
            print("looking for tweets between " + str(start_date) + " and " + str(end_date) + " ...")
            print(" path : {}".format(path))
            # number of tweets parsed
            tweet_parsed = 0
            # sleep
            sleep(random.uniform(0.5, 1.5))
            # start scrolling and get tweets
            driver, data, writer, tweet_ids, scrolling, tweet_parsed, scroll, last_position = \
                keep_scroling(driver, data, writer, tweet_ids, scrolling, tweet_parsed, limit, scroll, last_position)

            # keep updating <start date> and <end date> for every search
            if type(start_date) == str:
                start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d') + datetime.timedelta(days=interval)
            else:
                start_date = start_date + datetime.timedelta(days=interval)
            if type(start_date) != str:
                end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d') + datetime.timedelta(days=interval)
            else:
                end_date = end_date + datetime.timedelta(days=interval)
            sleep(random.uniform(5.5, 10.5))
        '''
        # Section: <Search By User>
        for account in from_accounts:
            # number of scrolls
            scroll = 0
            # log search page between <start_date> and <end_date>
            path = log_search_page(driver=driver, words=words, start_date=start_date,
                                   end_date=end_date, to_account=None,
                                   from_account=account, hashtag=hashtag, lang=lang,
                                   display_type=display_type, filter_replies=filter_replies, proximity=proximity)
            # number of logged pages (refresh each <interval>)
            refresh += 1
            last_position = driver.execute_script("return window.pageYOffset;")
            scrolling = True
            print("looking for tweets between " + str(start_date) + " and " + str(end_date) + " ...")
            print(" path : {}".format(path))
            tweet_parsed = 0
            sleep(random.uniform(0.5, 1.5))
            driver, data, writer, tweet_ids, scrolling, tweet_parsed, scroll, last_position = \
                keep_scroling(driver, data, writer, tweet_ids, scrolling, tweet_parsed, limit, scroll,
                              last_position)
            to_account.append(account)
            pd.DataFrame({'Name': to_account}).to_csv(r'./outputs/data/Scrawled.csv', index=False)
            sleep(random.uniform(5.5, 10.5))

    # data = pd.DataFrame(data, columns=['UserScreenName', 'UserName', 'Timestamp', 'Text', 'Embedded_text', 'Emojis',
    #                                   'Comments', 'Likes', 'Retweets', 'Image link', 'Tweet URL'])

    # close the web driver
    driver.close()

    # return data


def userInfoDetails(wait=3.0):
    saveBase = r'./outputs/data'
    os.makedirs(saveBase, exist_ok=True)
    AIFollowers = pd.read_csv('outputs/Crawl/followers.csv')['0'].tolist()
    AIFollowers = [user[1:] for user in AIFollowers]
    print('> Before Load:', len(AIFollowers))
    try:
        InfoDB = json.load(open(os.path.join(saveBase, 'followerInfo.json')))
    except FileNotFoundError:
        InfoDB = []
    for item in InfoDB:
        UserName = item['user']
        AIFollowers.remove(UserName)
    print('> After deduplicate:', len(AIFollowers))

    driver = init_driver(headless=True, proxy=None, show_images=False)
    # log_in(driver=driver)
    for user in AIFollowers:
        driver.get('https://twitter.com/' + user)
        sleep(random.uniform(wait - 0.5, wait + 0.5))
        # Section: find the following button
        try:
            element = driver.find_element(By.XPATH, f"//a[contains(@href, '/{user}/following')]")
            followingN = element.text.split(' ')[0]
        except NoSuchElementException:
            # FIXME: protected --> no link
            try:
                followingN = driver.find_element(By.XPATH, '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div[1]/div/div[3]/div/div/div[1]/div[2]/div[4]/div[1]/div/span[1]/span').text
            except NoSuchElementException:
                followingN = 0
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the follower button
        try:
            element = driver.find_element(By.XPATH, f"//a[contains(@href, '/{user}/followers')]")
            followerN = element.text.split(' ')[0]
        except NoSuchElementException:
            # FIXME: protected --> no link
            try:
                followerN = driver.find_element(By.XPATH, '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div[1]/div/div[3]/div/div/div[1]/div[2]/div[4]/div[2]/div/span[1]/span').text
            except NoSuchElementException:
                followerN = 0
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the Location button
        try:
            location = driver.find_element(By.XPATH,
                                           '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div[1]/div/div[3]/div/div/div/div/div[4]/div/span[2]/span/span').text
        except:
            location = ''
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the Profession button
        try:
            profession = driver.find_element(By.XPATH,
                                             '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div[1]/div/div[3]/div/div/div/div/div[4]/div/span[1]/span/span').text
        except:
            profession = ''

        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the SelfIntro button
        try:
            selfIntro = driver.find_element(By.XPATH,
                                             '//*[@id="react-root"]/div/div/div[2]/main/div/div/div/div[1]/div/div[3]/div/div/div/div/div[3]/div/div/span').text
        except:
            selfIntro = ''

        sleep(random.uniform(wait - 0.5, wait + 0.5))

        print(user, followingN, followerN, location, profession, selfIntro)
        InfoDB.append({'user': user, 'following': followingN, 'follower': followerN, 'location': location, 'profession': profession, 'selfIntro': selfIntro})
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        if len(InfoDB) % 50 == 0:
            json.dump(InfoDB, open(r'./outputs/data/followerInfo.json', 'w', encoding='gbk'), indent=4)

    json.dump(InfoDB, open(r'./outputs/data/followerInfo.json', 'w', encoding='gbk'), indent=4)


def updateUserInfo(wait=1.0):
    Path = r'./outputs/data/followerInfo.json'
    InfoDB = json.load(open(Path, 'r'))
    OkInfo = json.load(open(r'./outputs/data/followerInfo_1.json', 'r'))
    assert len(InfoDB) == len(OkInfo)
    driver = init_driver(headless=True, proxy=None, show_images=False)

    for indices, item in enumerate(InfoDB):
        if InfoDB[indices] != OkInfo[indices]:
            InfoDB[indices] = OkInfo[indices]
            continue

        UserName = item['user']
        print(f'[{UserName}] start re-crawl...{item}')
        driver.get('https://twitter.com/' + UserName)
        sleep(random.uniform(wait - 0.5, wait + 0.5))
        # Section: find the following button
        try:
            element = driver.find_element(By.XPATH, "//span[text()='正在关注']/../../span[1]")
            followingN = element.text.split(' ')[0]
        except NoSuchElementException:
            followingN = 0

        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the follower button
        try:
            element = driver.find_element(By.XPATH, "//span[text()='关注者']/../../span[1]")
            followerN = element.text.split(' ')[0]
        except NoSuchElementException:
            followerN = 0
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the Location button
        try:
            location = driver.find_element(By.XPATH,
                                           "//span[@data-testid='UserLocation']/span").text
        except NoSuchElementException:
            location = ''
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the Profession button
        try:
            profession = driver.find_element(By.XPATH, "//span[@data-testid='UserProfessionalCategory']/span").text
        except NoSuchElementException:
            profession = ''

        sleep(random.uniform(wait - 0.5, wait + 0.5))

        # Section: find the SelfIntro button
        try:
            selfIntro = driver.find_element(By.XPATH, "//div[@data-testid='UserDescription']/span").text
        except NoSuchElementException:
            selfIntro = ''
        
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        print(UserName, followingN, followerN, location, profession, selfIntro)
        InfoDB[indices] = ({'user': UserName, 'following': followingN, 'follower': followerN, 'location': location,
                            'profession': profession, 'selfIntro': selfIntro})
        sleep(random.uniform(wait - 0.5, wait + 0.5))

        if indices % 50 == 0:
            json.dump(InfoDB, open(r'./outputs/data/followerInfo_FULL.json', 'w', encoding='gbk'), indent=4)

    json.dump(InfoDB, open(r'./outputs/data/followerInfo_FULL.json', 'w', encoding='gbk'), indent=4)


if __name__ == '__main__':
    # get_users_follow(users=['OpenAI'], headless=True, verbose=0, wait=5)
    # userInfoDetails(wait=1.0)
    # scrap(start_date='2023-04-17', max_date='2023-04-19', words='ChatGPT')
    # updateUserInfo()
    # followers = pd.read_csv(r'./outputs/data/FollowerFull.csv')['Name'].tolist()
    # UserScrawledPath = pd.read_csv(r'./outputs/data/Scrawled.csv')['Name'].tolist()
    # followers = list(set(followers) - set(UserScrawledPath))
    # scrap(start_date='2022-11-01', words='ChatGPT', from_accounts=followers, to_account=UserScrawledPath)
    followers = open(r'./downloads/FollowerNet', 'r').readlines()
    followers = [line.strip() for line in followers]
    followers = ['Aziz_SF_AlSaud']
    get_following(users=followers, headless=True)
